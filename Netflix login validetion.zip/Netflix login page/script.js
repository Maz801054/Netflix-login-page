function Netfilx() {
  var a = document.getElementById("first").value;
  if (a == "") {
    alert("Please enter your email ");
  }
  var b = document.getElementById("second").value;
  if (b == "") {
    alert("Please enter your password");
  } else {
    alert("Thanks for submition!");
  }
}
